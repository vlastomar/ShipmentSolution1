﻿namespace ShipmentSolution.Web.ViewModels
{
    public class Class1
    {

    }
}
