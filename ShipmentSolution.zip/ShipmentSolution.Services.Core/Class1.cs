﻿namespace ShipmentSolution.Services.Core
{
    public class Class1
    {

    }
}
