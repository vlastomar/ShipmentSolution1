﻿namespace ShipmentSolution.GCommon
{
    public class Class1
    {

    }
}
