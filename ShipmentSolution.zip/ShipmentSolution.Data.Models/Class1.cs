﻿namespace ShipmentSolution.Data.Models
{
    public class Class1
    {

    }
}
