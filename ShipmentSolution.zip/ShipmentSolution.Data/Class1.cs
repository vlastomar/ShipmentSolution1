﻿namespace ShipmentSolution.Data
{
    public class Class1
    {

    }
}
